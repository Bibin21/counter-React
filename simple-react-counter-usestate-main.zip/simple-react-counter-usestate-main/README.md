# Simple React Counter using the useState hook

This project was created using Vite. Available scripts:

```
npm run dev
npm run build
npm run preview
```
